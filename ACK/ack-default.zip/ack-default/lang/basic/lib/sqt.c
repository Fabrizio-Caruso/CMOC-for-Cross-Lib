#define __NO_DEFS
#include <math.h>
#include "lib.h"

double _sqt(double x) { return sqrt(x); }
