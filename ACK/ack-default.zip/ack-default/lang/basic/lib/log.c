#define __NO_DEFS
#include <math.h>
#include "lib.h"

double _log(double x)
{
	return log(x);
}
