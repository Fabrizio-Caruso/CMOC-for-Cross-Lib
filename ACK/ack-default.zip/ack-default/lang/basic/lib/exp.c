#define __NO_DEFS
#include <math.h>
#include "lib.h"

double _exp(double x)
{
	return exp(x);
}
