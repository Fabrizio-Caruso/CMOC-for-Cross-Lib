extern	double _exp();
double EXP(statlink, x)
  int *statlink; double x;
  {return(_exp(x));}
