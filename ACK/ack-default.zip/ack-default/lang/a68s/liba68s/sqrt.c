extern	double _sqrt();
double SQRT(statlink, x)
  int *statlink; double x;
  {return(_sqt(x));}
