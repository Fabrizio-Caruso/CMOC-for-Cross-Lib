/*  Copyright (c) 2019 ACK Project.
 *  See the copyright notice in the ACK home directory, 
 *  in the file "Copyright".
 *
 *  Created on: 2019-02-09
 *  
 */
#ifndef EXPR_H_
#define EXPR_H_

/*	The rank of the operator oper is returned. */
int rank_of(int oper);

#endif /* EXPR_H_ */
