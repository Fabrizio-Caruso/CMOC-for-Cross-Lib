/* $Id$ */
/*
 * (c) copyright 1987 by the Vrije Universiteit, Amsterdam, The Netherlands.
 * See the copyright notice in the ACK home directory, in the file "Copyright".
 */
# define MAXINT 32767
# define MININT -32768
# define MAXLONG 2147483647
# define MINLONG -2147483648
# define EPSFLOAT 2.938736e-39
# define MAXFLOAT 1.7014117e38
# define EPSDOUBLE 2.938736e-39
/* for 64-bit double  1.701411834604692293e38 */
# define MAXDOUBLE 1.7014117e38
