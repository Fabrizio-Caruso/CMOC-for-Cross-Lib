/*
 * (c) copyright 1987 by the Vrije Universiteit, Amsterdam, The Netherlands.
 * See the copyright notice in the ACK home directory, in the file "Copyright".
 */
/* $Id$ */
/*		A S M			*/

/*ARGSUSED*/
code_asm(s, l)
	char *s;
	int l;
{
	/*	'asm' '(' string ')' ';'
	*/
	error("\"asm\" instruction not implemented");
}
