/*
 * fwrite.c - write a number of array elements on a file
 */
/* $Id$ */

#include <stdio.h>

#if ACKCONF_WANT_STDIO

size_t
fwrite(const void* ptr, size_t size, size_t nmemb,
    FILE* stream)
{
	const unsigned char* cp = ptr;
	size_t s;
	size_t ndone = 0;

	if (size)
		while (ndone < nmemb)
		{
			s = size;
			do
			{
				if (putc((int)*cp, stream)
				    == EOF)
					return ndone;
				cp++;
			} while (--s);
			ndone++;
		}
	return ndone;
}

#endif
