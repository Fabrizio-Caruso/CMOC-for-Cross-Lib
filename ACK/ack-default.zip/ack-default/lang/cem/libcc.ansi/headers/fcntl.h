/*
 * fcntl.h - file I/O primitives
 */
/* $Id$ */

#ifndef _FCNTL_H
#define _FCNTL_H

#include <unistd.h>

#endif
