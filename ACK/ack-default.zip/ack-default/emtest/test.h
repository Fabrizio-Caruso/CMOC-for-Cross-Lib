/* $Id$ */
/*
 * (c) copyright 1987 by the Vrije Universiteit, Amsterdam, The Netherlands.
 * See the copyright notice in the ACK home directory, in the file "Copyright".
 */
/*#define W2S	4	/* double word size */
/*#define FS 	4	/* float size */
/*#define F2S	8	/* double size */
