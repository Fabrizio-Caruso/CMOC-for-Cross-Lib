//fastspi header
unsigned int xferspif(unsigned int);
unsigned int xferspif2(unsigned int); //uses N1(port 2) as clock
unsigned int shiftinf();	//routine just reads a byte
void shiftoutf(unsigned int); //routine just writes a byte
