lccproloX.h and lccepiloX are the prolog and epilog for the various versions of the compiler
fl is the latest suffix for st judy's compiler
LCC1802fp.inc is the assembler floating point routines
IO1802.inc is the assembler language i/o routines(used to be putc.inc)
nstdlib.h and .c are the c language headers and code for what would normally be stdlib and stdio
olduino.h and olduino.c are arduino type routines like digitalWrite and delay
anything else is specific to some test or example and really should be in another spot.
