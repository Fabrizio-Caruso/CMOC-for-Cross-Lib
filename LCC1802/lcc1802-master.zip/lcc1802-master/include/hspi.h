unsigned char spixfer(unsigned char); //sends and receives a single character over hardware spi
void spiSend(unsigned char);		//variant declared with return value ignored
void spiSendN(unsigned char *, unsigned int); //sned a fixed length block
void spiReceive(unsigned char);		//variant declared with return value ignored
void spiReceiveN(unsigned char *, unsigned int); //read a fixed length block
