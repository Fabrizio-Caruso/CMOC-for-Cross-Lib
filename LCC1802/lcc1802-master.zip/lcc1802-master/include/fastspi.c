void spincluder(){
	asm("\tinclude fastspi.inc\n");
}
