//cpu1802spd4port7 - set up for 4mhz 1802 with host output via out 7.
#define putc(x) out(7,x)
#define __CPUSPEED4
#define __CPUTYPE1802
