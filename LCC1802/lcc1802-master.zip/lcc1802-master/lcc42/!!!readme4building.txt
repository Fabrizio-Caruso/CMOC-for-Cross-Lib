To build for windows with visual studio 19 use buildvisualstudio.bat
To build for windows with visual studio 17 use buildvs17
these uses makefile.nt

**it's easy to do that by just double clicking on the bat file**

To build for linux, mark abene provided a makefile makefile.linux
Mark says: 
  I've attached what I used on ubuntu. This would go in the lcc42 directory. 
  "make all" compiles everything, 
  and "make install" copies the results to a directory called "bin" within lcc42 (easily changed).