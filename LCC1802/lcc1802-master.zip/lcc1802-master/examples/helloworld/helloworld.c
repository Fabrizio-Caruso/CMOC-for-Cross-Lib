/*
   print the string "hello World!"
*/
#include <nstdlib.h>
void main()
{
	printstr("hello World!\n");
}
#include <nstdlib.c>
