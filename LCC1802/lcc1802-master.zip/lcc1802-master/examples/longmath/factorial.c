#include "nstdlib.h"
//#include "olduino.h"
long fact(long n){
	if (0==n) return 1;
	return n*fact(n-1);
}

void main()
{
	long n;
	for(n=1;n<=13;n++){
		printf("fact(%ld)=%ld\n",n,fact(n));
	}
}
#include "nstdlib.c"
//#include "olduino.c"
