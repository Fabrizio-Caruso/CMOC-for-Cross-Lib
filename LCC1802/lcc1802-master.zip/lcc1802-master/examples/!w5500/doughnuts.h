//15-03-16 corrected method=PUT to POST, version 1.2
	static unsigned char hdr1a[]="HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n" //beginning of header
						"<html><body OnLoad=\"document.mf.G.focus();\">"
						"<span style=\"color:#0000A0\">\r\n"
						"<center><b>OLDUINO 1802 DOUGHNUTS SERVER 1.2</b>"
						"<br>(";
	static unsigned char hdr1b[]=" pages served)" //end of header
						"</center>"
						"<h1> </h1>"; //to force some spacing
	static unsigned char hdr1aswas[]="HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n"
						"<html><body OnLoad=\"document.mf.G.focus();\">"
						"<span style=\"color:#0000A0\">\r\n"
						"<center><h2>Olduino 1802 Doughnuts Server 1.1<br>805 pages served</h2>"
						"</center>";
	static unsigned char Inst1[]=
		"I AM THINKING OF A 3 DIGIT NUMBER.<BR>TRY TO GUESS " //50
		"MY NUMBER AND I WILL GIVE YOU CLUES AS FOLLOWS:<BR>";
	static unsigned char Inst2[]=
		"...PICO - ONE DIGIT IS IN THE WRONG PLACE<BR>"
		"...FERMI - ONE DIGIT IS IN THE CORRECT PLACE<BR>"
        "...DOUGHNUTS - NO DIGIT IS CORRECT<P>";
	static unsigned char Reminder[]=
		"REMEMBER:<BR>";
	static unsigned char gform[]="<p><form name=\"mf\" method=\"GET\">\r\n"
						"<input type=\"text\" name=\"G\">"
						"<input type=\"submit\" value=\"Enter Your Guess\">\r\n"
						"</form>";
	static unsigned char trlr[]="</body></html>\r\n\r\n";

	static unsigned char pform[]="<p><form method=\"POST\">\r\n"
						"<input type=\"submit\" value=\"Press To Play Again\">\r\n"
						"</form>";

	static unsigned char olduinolink[]="<a href=\"http://goo.gl/RYbPYC\">Olduino</a>: An Arduino for the First of Us<p>";

