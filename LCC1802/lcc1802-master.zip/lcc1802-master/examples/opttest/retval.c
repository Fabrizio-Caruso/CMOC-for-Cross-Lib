float fourtytwo=42, minusfourtytwo=-42, fourty=40, minusfourty=-40;
float one=1, minusone=-1,pigs=7;
int intfun(){
	return 7;
}
void main()
{
	int i,j,k;
	i=intfun()*7;
	if (i==j) k=0;
}

