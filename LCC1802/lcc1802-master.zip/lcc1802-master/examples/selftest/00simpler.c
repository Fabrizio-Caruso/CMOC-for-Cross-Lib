void main( ) {
int i;
i+=2;
}
