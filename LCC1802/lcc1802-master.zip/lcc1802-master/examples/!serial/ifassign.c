void putcser(char);
void main(){
	int x;
	if (x=0)
		x++;
}
