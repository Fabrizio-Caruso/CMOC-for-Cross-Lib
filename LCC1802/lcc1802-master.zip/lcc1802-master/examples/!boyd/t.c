void main(){
	register unsigned char* mem=0;
	unsigned char k=0;
	mem[3]=42;
	mem[3]=k<<4;
}
