void hexDump(uint8_t *data, uint16_t len);
