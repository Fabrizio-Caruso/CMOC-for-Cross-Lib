int memcmp(const void *Ptr1, const void *Ptr2, unsigned int Count){
/*	unsigned char* p1; unsigned char *p2;
    int v = 0;
    p1 = (unsigned char *)Ptr1;
    p2 = (unsigned char *)Ptr2;

    while(Count-- > 0 && v == 0) {
//        v = *(p1++) - *(p2++);
    }
*/
    return 0;
}
void main(){
	int pigs;
	pigs=memcmp(0,0,0);
	//if (memcmp(0,0,0)){
	//	pigs=3;
	//}
}
