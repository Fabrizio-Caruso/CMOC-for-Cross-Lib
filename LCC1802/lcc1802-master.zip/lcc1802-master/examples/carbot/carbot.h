//carbot.h defines for the carbot wall follower
#define pwma 1	//pwm for $a side
#define pwmb 0	//pwm for $b side
#define bin1 3	//front motor pole for $b
#define bin2 2	//back
#define ain1 4	//front motor pole for $a side
#define ain2 5	//back
