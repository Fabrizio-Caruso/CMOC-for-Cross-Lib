unsigned int	pingQ();
