#ifndef _CODE78K2_H
#define _CODE78K2_H
/* code78k2.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator 78K2-Familie                                                */
/*                                                                           */
/*****************************************************************************/

extern void code78k2_init(void);
#endif /* _CODE78K2_H */
