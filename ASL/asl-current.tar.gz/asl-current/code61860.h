#ifndef _CODE61860_H
#define _CODE61860_H
/* code61860.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Sharp SC61860                                               */
/*                                                                           */
/*****************************************************************************/

extern void code61860_init(void);
#endif /* _CODE61860_H */
