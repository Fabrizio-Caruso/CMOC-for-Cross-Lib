#ifndef _CODE2650_H
#define _CODE2650_H
/* code2650.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Signetics 2650                                              */
/*                                                                           */
/*****************************************************************************/

extern void code2650_init(void);
#endif /* _CODE2650_H */
