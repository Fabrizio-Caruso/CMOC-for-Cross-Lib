#ifndef _CODE86_H
#define _CODE86_H
/* code86.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator 8086/V-Serie                                                */
/*                                                                           */
/* Historie:                                                                 */
/*                                                                           */
/*****************************************************************************/

extern void code86_init(void);
#endif /* _CODE86_H */
