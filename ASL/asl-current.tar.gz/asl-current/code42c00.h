#ifndef _CODE42C00_H
#define _CODE42C00_H
/* code42c00.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* ASL                                                                       */
/*                                                                           */
/* Target Toshiba TLCS-42                                                    */
/*                                                                           */
/*****************************************************************************/

extern void code42c00_init(void);
#endif /* _CODE42C00_H */
