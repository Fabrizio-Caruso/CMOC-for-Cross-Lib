#ifndef _CODE807X_H
#define _CODE807X_H
/* codescmp.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator National INS807x                                            */
/*                                                                           */
/*****************************************************************************/

extern void code807x_init(void);
#endif /* _CODE807X_H */
