#ifndef _CODESCMP_H
#define _CODESCMP_H
/* codescmp.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator National SC/MP                                              */
/*                                                                           */
/* Historie: 17.2.1996 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void codescmp_init(void);
#endif /* _CODESCMP_H */
