#ifndef _CODEVAX_HPP
#define _CODEVAX_HPP

/* Declare this in a header file so CLang++ does not complain
   about unused inline functions: */

# include "cppops.h"
DefCPPOps_Mask(cpu_cap_t)

#endif /* _CODEVAX_HPP */
