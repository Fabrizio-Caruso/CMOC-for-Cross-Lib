#ifndef _CODE53C8XX_H
#define _CODE53C8XX_H
/* code53c8xx.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* Makroassembler AS                                                         */
/*                                                                           */
/* Codegenerator SYM53C8xx                                                   */
/*                                                                           */
/* Historie: 30. 9.1998 angelegt                                             */
/*                                                                           */
/*****************************************************************************/

extern void code53c8xx_init(void);
#endif /* _CODE53C8XX_H */
