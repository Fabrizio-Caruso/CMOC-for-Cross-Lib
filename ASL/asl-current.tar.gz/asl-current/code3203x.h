#ifndef _CODE3203X_H
#define _CODE3203X_H
/* code3203x.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator TMS320C3x-Familie                                           */
/*                                                                           */
/* Historie: 12.12.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code3203x_init(void);
#endif /* _CODE3203X_H */
