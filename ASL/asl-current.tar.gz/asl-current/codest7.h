#ifndef _CODEST7_H
#define _CODEST7_H
/* codest7.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator SGS-Thomson ST7                                             */
/*                                                                           */
/* Historie: 21.5.1997 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void codest7_init(void);
#endif /* _CODEST7_H */
