#ifndef _CODENS32K_HPP
#define _CODENS32K_HPP

/* Declare this in a header file so CLang++ does not complain
   about unused inline functions: */

# include "cppops.h"
DefCPPOps_Enum(tFPU)
DefCPPOps_Enum(tPMMU)

#endif /* _CODENS32K_HPP */
