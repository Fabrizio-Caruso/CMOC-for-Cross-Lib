#ifndef _CODE601_H
#define _CODE601_H
/* code601.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator PowerPC-Familie                                             */
/*                                                                           */
/* Historie: 17.10.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code601_init(void);
#endif /* _CODE601_H */
