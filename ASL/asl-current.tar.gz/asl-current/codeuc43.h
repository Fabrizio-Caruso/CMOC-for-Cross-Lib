#ifndef _CODEUC43_H
#define _CODEUC43_H
/* codeuc43.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS                                                                        */
/*                                                                           */
/* Code Generator NEC uCOM-43                                                */
/*                                                                           */
/*****************************************************************************/

extern void codeuc43_init(void);

#endif /* _CODEUC43_H */
