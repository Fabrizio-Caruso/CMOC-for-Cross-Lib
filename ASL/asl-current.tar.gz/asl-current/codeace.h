#ifndef _CODEACE_H
#define _CODEACE_H
/* codeace.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegeneratormodul ACE-Familie                                            */
/*                                                                           */
/* Historie:14. 8.1996 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void codeace_init(void);
#endif /* _CODEACE_H */
