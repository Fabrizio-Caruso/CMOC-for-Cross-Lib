#ifndef _CODE62015_H
#define _CODE62015_H
/* code62015.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Sharp SC62015                                               */
/*                                                                           */
/*****************************************************************************/

extern void code62015_init(void);
#endif /* _CODE62015_H */
