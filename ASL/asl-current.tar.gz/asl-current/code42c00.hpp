#ifndef _CODE42C00_HPP
#define _CODE42C00_HPP

/* Declare this in a header file so CLang++ does not complain
   about unused inline functions: */

# include "cppops.h"
DefCPPOps_Mask(cpu_flags_t)

#endif /* _CODE42C00_HPP */
