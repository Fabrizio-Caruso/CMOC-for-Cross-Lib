#ifndef _CODE65_H
#define _CODE65_H
/* code65.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator 65xx/MELPS740                                               */
/*                                                                           */
/* Historie: 17.8.1996 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void code65_init(void);
#endif /* _CODE65_H */
