#ifndef _CODEXA_H
#define _CODEXA_H
/* codexa.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* AS-Codegenerator Philips XA                                               */
/*                                                                           */
/* Historie: 25.10.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void codexa_init(void);
#endif /* _CODEXA_H */
