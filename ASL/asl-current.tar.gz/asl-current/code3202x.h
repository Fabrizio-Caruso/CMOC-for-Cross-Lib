#ifndef _CODE3202X_H
#define _CODE3202X_H
/*
 * AS-Portierung
 *
 * AS-Codegeneratormodul fuer die Texas Instruments TMS320C2x-Familie
 *
 * 19.08.96: Erstellung
 */

extern void code3202x_init(void);
#endif /* _CODE3202X_H */
