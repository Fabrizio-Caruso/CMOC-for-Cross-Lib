#ifndef _MOTPSEUDO_HPP
#define _MOTPSEUDO_HPP

/* Declare this in a header file so CLang++ does not complain
   about unused inline functions: */

#include "cppops.h"
DefCPPOps_Mask(moto_pseudo_flags_t)

#endif /* _MOTPSEUDO_HPP */
