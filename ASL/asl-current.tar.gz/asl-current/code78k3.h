#ifndef _CODE78K3_H
#define _CODE78K3_H
/* code78k3.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator 78K3-Familie                                                */
/*                                                                           */
/*****************************************************************************/

extern void code78k3_init(void);

#endif /* _CODE78K3_H */
