#ifndef _INTPSEUDO_HPP
#define _INTPSEUDO_HPP

/* Declare this in a header file so CLang++ does not complain
   about unused inline functions: */

#include "cppops.h"
DefCPPOps_Mask(int_pseudo_flags_t)

#endif /* _INTPSEUDO_HPP */
