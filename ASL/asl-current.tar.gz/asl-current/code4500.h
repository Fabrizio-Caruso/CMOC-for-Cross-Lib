#ifndef _CODE4500_H
#define _CODE4500_H
/* code4500.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator MELPS-4500                                                  */
/*                                                                           */
/* Historie: 31.12.1996 (23.44!!) Grundsteinlegung                           */
/*                                                                           */
/*****************************************************************************/

extern void code4500_init(void);
#endif /* _CODE4500_H */
