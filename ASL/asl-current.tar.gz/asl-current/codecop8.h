#ifndef _CODECOP8_H
#define _CODECOP8_H
/* codecop8.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegeneratormodul COP8-Familie                                           */
/*                                                                           */
/* Historie: 7.10.1996 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void codecop8_init(void);
#endif /* _CODECOP8_H */
