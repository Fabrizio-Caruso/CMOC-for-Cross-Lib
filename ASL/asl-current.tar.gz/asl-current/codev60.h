#ifndef _CODEV60_H
#define _CODEV60_H
/* codev60.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS                                                                        */
/*                                                                           */
/* Code Generator NEC V60                                                    */
/*                                                                           */
/*****************************************************************************/

extern void codev60_init(void);
#endif /* _CODEV60_H */
