#ifndef _CODE17C4X_H
#define _CODE17C4X_H
/* code17c4x.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator PIC17C4x                                                    */
/*                                                                           */
/* Historie: 21.8.1996 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void code17c4x_init(void);
#endif /* _CODE17C4X_H */
